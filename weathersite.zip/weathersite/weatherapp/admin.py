from django.contrib import admin
from .models import TPH

admin.site.register(TPH)
