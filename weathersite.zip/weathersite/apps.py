from django.apps import AppConfig

class weatherSiteConfig(AppConfig):
    name = 'weatherapp'
